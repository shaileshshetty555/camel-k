#!/bin/bash
#
# Origin: https://github.ibm.com/katamari/changelog/blob/main/onboarding/jenkins/.changelog.setup.sh
#
# Required variables you must set: 
#
# 1. CL_ORG - this is the org of your project - e.g. katamari 
# 
# 2. CL_REPO - this is the name of your repo - e.g. connector-ui
# 
# 3. CL_BRANCH - this is the branch into which you are merging code for image production
#                e.g. main, release-3.1 
# 
# 4. CL_IMAGE_NAME - must be full 'push' image name, minus tag
#                    e.g. hyc-cp4mcm-team-docker-local.artifactory.swg-devops.com/connector/connector-ui
#  
# Optional variables you may want to set: 
#
# 1. CL_DEBUG - specify "true" for debug output and changelog generation during pull request. 
#       
# 2. CL_ALL_COMMITS - specify "true" to ensure changelog contains all commits, even those more
#    recent than the current commit.  This is most commonly used for debugging push events.
#
# 3. CL_TEST_BRANCH - specifies branch name of katamari/changelog repo to checkout and test
#    during changelog script processing.  This is used to test staged changelog code. 
#
# 4. CL_PROJECT_TYPE - specifies whether this project produces an image or a package (e.g. NPM package).
#    supported values are 'image' or 'package'.  The default is 'image'.
#
# 5. CL_PACKAGE_FILE - specifies name of package file (e.g. package.json).  For 'image' type projects
#    this results in a dependencies section being added to the changelog.  For 'package' type projects
#    this results in a change log being generated and written to the 'packages' path in the 
#    changelog.data repo. 
#
# 6. CL_SINCE - specifies date in yyy-mm-dd format that designates only pull requests 
#               more recently than specified date should be included in the change log. 
#
# Git Authorization and Access: 
# 
#   CL_TOKEN - should be set externally via GITHUB_TOKEN.  This is a GIT Personal Access 
#              token (PAT) and requires:
# 
#              1. RW access to katamari/changelog.data (clones and pushes change)
#              2. R access to katamari/changelog (clones)
#              3. R access to katamari/dev-issues-tracking (reads issues)
#              4. R access to your project repo (reads pull requests and issues)
#----------------------------------------------------------------------------------------
#
# Required variables you must set: 
#
export CL_ORG="katamari"
export CL_REPO="camel-k"
export CL_BRANCH="main"
export CL_IMAGE_NAME="hyc-connector-framework-team-camel-k-docker-local.artifactory.swg-devops.com/camel-k/camel-k"
#
# Optional variables you may want to set: 
#
export CL_DEBUG="true"       
#export CL_ALL_COMMITS="true"
#export CL_TEST_BRANCH="<branch-name>"
#export CL_PROJECT_TYPE="image"
#export CL_PACKAGE_FILE="package.json" 
#export CL_SINCE="2020-09-01"
#
# Required variables you probably do not need to alter: 
#
export CL_TOKEN=$GITHUB_TOKEN
export CL_GITHUB_HOSTNAME="https://github.ibm.com"
export CL_REPO_URL="$CL_GITHUB_HOSTNAME/$CL_ORG/$CL_REPO"
export CL_BUILD_PLATFORM="tekton"