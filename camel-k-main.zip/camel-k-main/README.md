# camel-k
This repository hosts the Katamari fork of the Camel K Operator

## Repository 

Branches: 

* main: defaut (same contents as v1.2.1 now)
* v1.2.1: community v1.2.1 unchanged
* v1.3.2: community v1.3.2 unchanged
* release-3.1: 3.1 release

Build pipeline is setup here: https://cloud.ibm.com/devops/toolchains/b5d6720e-467e-456f-9b0f-185c561db4c9?env_id=ibm:yp:us-south

The image goes: hyc-connector-framework-team-camel-k-docker-local/camel-k/camel-k/

## Build 

### Setup

Refer to: https://camel.apache.org/camel-k/latest/contributing/developers.html#requirements

### Full build


Execute `make` in the project root directory

### Camel-k-runtine dependencies (patch) pick up build

Execute `make package-artifacts` in the project root directory

### Integration dependencies pick up build

set the github PAT into `PAT` variable.
Execute `./build/dependencies.sh` in the project root directory

### Docker image build

Execute `make images` in the project root directory

## Development install via CLI

1. Login to OCP project

1. Execute './tag-and-push.sh "artifactory id" "aritfactory API key"` in `deploy/katamari` directory

1. Execute `./deploy.sh  "artifactory id" "aritfactory API key"`



Build 9
