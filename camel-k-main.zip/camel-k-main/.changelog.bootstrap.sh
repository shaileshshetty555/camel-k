#!/bin/bash
# 
# Origin:
# https://github.ibm.com/katamari/changelog/blob/main/onboarding/.changelog.bootstrap.sh
#  
#
# Purpose: Runs changelog-travis.sh integration from a travis job
#
# Syntax:
# 
#    ./.changelog.bootstrap.sh [<digest>]
#
# Where <digest> is optional image digest in form sha256:<hexadecimal digest value>.  This is an optional
# parameter.  If not specified, changelog will attempt to find it on your image in the local docker
# cache on the build machine on which changelog runs. If no digest is found, changelog ends in error.
#
# Writes to "changelog.data" repository in format:
# 
# images:
#   <image-name>: 
#       branches:
#          <branch-name>:  
#               <repo-name>@<digest>.changelog.json 
#
export CL_BOOTSTRAP_VERSION='1.4' # version of this file 

echo ".changelog.bootstrap.sh begin"
echo "Running boostrap version "$CL_BOOTSTRAP_VERSION

# start with clean slate
let rc='0'

# setup user variables 
setup=.changelog.setup.sh
echo Run $setup to set user variables
if [ -e $setup ]; then
    . $setup 
else
    echo "$setup not found. It must be found in your project root directory and your"
    echo "project root directory must be the current directory when you invoke this"
    echo "script, $(basename $0). Terminating in error."
    exit 1
fi

# dump changelog environment variables 
export | grep "CL_"

cd .. 
rm -rf changelog 
git clone https://${CL_TOKEN}@github.ibm.com/katamari/changelog.git

if [ -e changelog ]; then 
    cd changelog
    # if testing staged level of changelog, check it out
    if [ $CL_TEST_BRANCH ]; then 
        git checkout $CL_TEST_BRANCH
    fi 
else 
    echo 'Could not clone changelog git repo. Terminating in error.'
    let rc='1'
fi 

# check jq prereq 

# check prereq 
if [ $rc -eq 0 ]; then 
    echo '{"test":"validated: jq is installed"}' | jq '.test' 2>/dev/null
    if [ $? -ne 0 ]; then 
        echo "Prereq jq not is installed."
        echo "So install ..."

        # copy correct jq binary according to architecture 
        sys=$(uname -m)
        if [ $sys = 'x86_64' ]; then
          echo "copy cp bin/jqbin/jq-linux64 bin/jq"
          cp bin/jqbin/jq-linux64 bin/jq 
        else
            if [ $sys = 'x86_32' ]; then
                echo "copy cp bin/jqbin/jq-linux32 bin/jq"
                cp bin/jqbin/jq-linux32 bin/jq 
            else
                echo "OS $sys unsupported by changelog. You can fix this problem by"
                echo "manually installing jq before using changelog. Terminating in error."
                rc=1 
            fi
        fi
        echo "Prereq jq is now installed."
    fi
fi 

if [ $rc -eq 0 ]; then 
    chmod 777 integrations/$CL_BUILD_PLATFORM/changelog-$CL_BUILD_PLATFORM.sh
    integrations/$CL_BUILD_PLATFORM/changelog-$CL_BUILD_PLATFORM.sh $@ 
    rc=$?
fi 

cd ..

# leave things tidy, then say goodbye 
rm -rf changelog
rm -rf changelog.data 
echo .changelog.bootstrap.sh  end - RC=$rc
exit $rc 