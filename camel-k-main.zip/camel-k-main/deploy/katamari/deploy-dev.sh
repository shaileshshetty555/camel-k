#!/bin/sh

oc create secret docker-registry artifactory --docker-server=hyc-connector-framework-team-camel-k-docker-local.artifactory.swg-devops.com --docker-username=$1 --docker-password=$2 --docker-email=docker@ibm.com
oc apply -f service-account.yaml
oc apply -f role-bindings.yaml
oc apply -f ../crd-build.yaml
oc apply -f ../crd-camel-catalog.yaml
oc apply -f ../crd-integration.yaml
oc apply -f ../crd-integration-kit.yaml
oc apply -f ../crd-integration-platform.yaml
oc apply -f ../crd-kamelet.yaml
oc apply -f ../crd-kamelet-binding.yaml
oc apply -f ../operator-role-olm.yaml
oc apply -f ../operator-role-olm-cluster.yaml
oc apply -f ../operator-deployment.yaml
