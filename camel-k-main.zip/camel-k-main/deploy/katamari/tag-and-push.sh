#!/bin/sh

docker login hyc-connector-framework-team-camel-k-docker-local.artifactory.swg-devops.com -u $1 -p $2
docker tag apache/camel-k:1.3.2 hyc-connector-framework-team-camel-k-docker-local.artifactory.swg-devops.com/test/camel-k:1.3.2
docker push hyc-connector-framework-team-camel-k-docker-local.artifactory.swg-devops.com/test/camel-k:1.3.2